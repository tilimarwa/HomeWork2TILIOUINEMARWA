// matrix_operations.c
#include "matrix_operations.h"
#include<stdio.h>

void matrix_multiply(int* A, int* B, int* C, int n, int local_n) {
    // Assuming A, B, and C are row-major matrices
    for (int i = 0; i < local_n; ++i) {
        for (int j = 0; j < n; ++j) {
            C[i * n + j] = 0;
            for (int k = 0; k < n; ++k) {
                C[i * n + j] += A[i * n + k] * B[k * n + j];
            }
        }
    }
}

void print_matrix(int* matrix, int n) {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            printf("%d ", matrix[i * n + j]);
        }
        printf("\n");
    }
    printf("\n");
}
