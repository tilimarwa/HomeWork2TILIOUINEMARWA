// matrix_operations.h
#ifndef MATRIX_OPERATIONS_H
#define MATRIX_OPERATIONS_H

void matrix_multiply(int* A, int* B, int* C, int n, int local_n);
void print_matrix(int* matrix, int n);

#endif  // MATRIX_OPERATIONS_H
