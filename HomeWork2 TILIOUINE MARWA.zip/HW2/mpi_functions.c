// mpi_functions.c
#include "mpi_functions.h"

void scatter_matrix(int* A, int* local_A, int n, int local_n, int root) {
    MPI_Scatter(A, local_n * n, MPI_INT, local_A, local_n * n, MPI_INT, root, MPI_COMM_WORLD);
}

void gather_matrix(int* local_C, int* C, int n, int local_n, int root) {
    MPI_Gather(local_C, local_n * n, MPI_INT, C, local_n * n, MPI_INT, root, MPI_COMM_WORLD);
}

void broadcast_matrix_size(int* n, int root) {
    MPI_Bcast(n, 1, MPI_INT, root, MPI_COMM_WORLD);
}
