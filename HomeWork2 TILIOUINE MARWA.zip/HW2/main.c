// main.c
#include <stdio.h>
#include <stdlib.h>
#include "matrix_operations.h"
#include "mpi_functions.h"

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size != 2) {
        if (rank == 0) {
            fprintf(stderr, "Please run the program with 2 processes.\n");
        }
        MPI_Finalize();
        return EXIT_FAILURE;
    }

    int n = 4; // Example matrix size
    int local_n = n / size;

    int* A = NULL;
    int* B = NULL;
    int* C = NULL;

    if (rank == 0) {
        A = (int*)malloc(sizeof(int) * n * n);
        B = (int*)malloc(sizeof(int) * n * n);
        C = (int*)malloc(sizeof(int) * n * n);

        // Manually set values for matrices A and B
        int a_values[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        int b_values[] = {4, 3, 2, 1, 8, 7, 6, 5, 12, 11, 10, 9, 16, 15, 14, 13};

        for (int i = 0; i < n * n; ++i) {
            A[i] = a_values[i];
            B[i] = b_values[i];
        }

        printf("Matrix A:\n");
        print_matrix(A, n);

        printf("Matrix B:\n");
        print_matrix(B, n);
    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int* local_A = (int*)malloc(sizeof(int) * local_n * n);
    int* local_B = (int*)malloc(sizeof(int) * n * local_n);
    int* local_C = (int*)malloc(sizeof(int) * local_n * n);

    scatter_matrix(A, local_A, n, local_n, 0);
    scatter_matrix(B, local_B, n, local_n, 0);

    matrix_multiply(local_A, local_B, local_C, n, local_n);

    gather_matrix(local_C, C, n, local_n, 0);

    free(local_A);
    free(local_B);
    free(local_C);

    if (rank == 0) {
        printf("Result Matrix C:\n");
        print_matrix(C, n);

        free(A);
        free(B);
        free(C);
    }

    MPI_Finalize();

    return 0;
}
