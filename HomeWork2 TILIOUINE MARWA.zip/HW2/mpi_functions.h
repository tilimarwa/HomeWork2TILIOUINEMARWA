// mpi_functions.h
#ifndef MPI_FUNCTIONS_H
#define MPI_FUNCTIONS_H

#include <mpi.h>

void scatter_matrix(int* A, int* local_A, int n, int local_n, int root);
void gather_matrix(int* local_C, int* C, int n, int local_n, int root);
void broadcast_matrix_size(int* n, int root);

#endif  // MPI_FUNCTIONS_H
